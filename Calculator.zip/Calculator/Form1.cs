﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {
            

        }

        private void numbLabel_Click(object sender, EventArgs e)
        {
            numbLabel.Text = "0";
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "7";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "7";
            }
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "8";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "8";
            }
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "9";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "9";
            }
        }

        private void divideButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "/";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "/";
            }
        }

        private void bkspcButton_Click(object sender, EventArgs e)
        {

            }

        private void fourButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "4";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "4";
            }
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "5";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "5";
            }
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "6";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "6";
            }
        }

        private void multButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "*";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "*";
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "C";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "C";
            }
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "1";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "1";
            }
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "2";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "2";
            }
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "3";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "3";
            }
        }

        private void minusButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "-";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "-";
            }
        }

        private void equalsButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "=";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "=";
            }
        }

        private void zeroButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "0";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "0";
            }
        }

        private void decimalButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = ".";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + ".";
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (numbLabel.Text == "0" && numbLabel.Text != null)
            {
                numbLabel.Text = "+";
            }
            else
            {
                numbLabel.Text = numbLabel.Text + "+";
            }
        }

        private void calGroup_Enter(object sender, EventArgs e)
        {

        }
    }
}
