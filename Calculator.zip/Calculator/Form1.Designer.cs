﻿namespace Calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numbLabel = new System.Windows.Forms.Label();
            this.sevenButton = new System.Windows.Forms.Button();
            this.eightButton = new System.Windows.Forms.Button();
            this.nineButton = new System.Windows.Forms.Button();
            this.divideButton = new System.Windows.Forms.Button();
            this.bkspcButton = new System.Windows.Forms.Button();
            this.fourButton = new System.Windows.Forms.Button();
            this.fiveButton = new System.Windows.Forms.Button();
            this.sixButton = new System.Windows.Forms.Button();
            this.multButton = new System.Windows.Forms.Button();
            this.oneButton = new System.Windows.Forms.Button();
            this.twoButton = new System.Windows.Forms.Button();
            this.threeButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.zeroButton = new System.Windows.Forms.Button();
            this.decimalButton = new System.Windows.Forms.Button();
            this.minusButton = new System.Windows.Forms.Button();
            this.equalsButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.calGroup = new System.Windows.Forms.GroupBox();
            this.calGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // numbLabel
            // 
            this.numbLabel.AutoSize = true;
            this.numbLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.numbLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.numbLabel.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numbLabel.Location = new System.Drawing.Point(144, 60);
            this.numbLabel.Name = "numbLabel";
            this.numbLabel.Size = new System.Drawing.Size(2, 26);
            this.numbLabel.TabIndex = 0;
            this.numbLabel.Click += new System.EventHandler(this.numbLabel_Click);
            // 
            // sevenButton
            // 
            this.sevenButton.Location = new System.Drawing.Point(6, 103);
            this.sevenButton.Name = "sevenButton";
            this.sevenButton.Size = new System.Drawing.Size(75, 23);
            this.sevenButton.TabIndex = 1;
            this.sevenButton.Text = "7";
            this.sevenButton.UseVisualStyleBackColor = true;
            this.sevenButton.Click += new System.EventHandler(this.sevenButton_Click);
            // 
            // eightButton
            // 
            this.eightButton.Location = new System.Drawing.Point(87, 103);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(75, 23);
            this.eightButton.TabIndex = 2;
            this.eightButton.Text = "8";
            this.eightButton.UseVisualStyleBackColor = true;
            this.eightButton.Click += new System.EventHandler(this.eightButton_Click);
            // 
            // nineButton
            // 
            this.nineButton.Location = new System.Drawing.Point(168, 101);
            this.nineButton.Name = "nineButton";
            this.nineButton.Size = new System.Drawing.Size(75, 25);
            this.nineButton.TabIndex = 3;
            this.nineButton.Text = "9";
            this.nineButton.UseVisualStyleBackColor = true;
            this.nineButton.Click += new System.EventHandler(this.nineButton_Click);
            // 
            // divideButton
            // 
            this.divideButton.Location = new System.Drawing.Point(249, 103);
            this.divideButton.Name = "divideButton";
            this.divideButton.Size = new System.Drawing.Size(75, 23);
            this.divideButton.TabIndex = 4;
            this.divideButton.Text = "/";
            this.divideButton.UseVisualStyleBackColor = true;
            this.divideButton.Click += new System.EventHandler(this.divideButton_Click);
            // 
            // bkspcButton
            // 
            this.bkspcButton.Image = global::Calculator.Properties.Resources.backspace_arrow_1_;
            this.bkspcButton.ImageKey = "(none)";
            this.bkspcButton.Location = new System.Drawing.Point(330, 101);
            this.bkspcButton.Name = "bkspcButton";
            this.bkspcButton.Size = new System.Drawing.Size(75, 23);
            this.bkspcButton.TabIndex = 5;
            this.bkspcButton.UseVisualStyleBackColor = true;
            this.bkspcButton.Click += new System.EventHandler(this.bkspcButton_Click);
            // 
            // fourButton
            // 
            this.fourButton.Location = new System.Drawing.Point(6, 132);
            this.fourButton.Name = "fourButton";
            this.fourButton.Size = new System.Drawing.Size(75, 23);
            this.fourButton.TabIndex = 6;
            this.fourButton.Text = "4";
            this.fourButton.UseVisualStyleBackColor = true;
            this.fourButton.Click += new System.EventHandler(this.fourButton_Click);
            // 
            // fiveButton
            // 
            this.fiveButton.Location = new System.Drawing.Point(87, 132);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(75, 23);
            this.fiveButton.TabIndex = 7;
            this.fiveButton.Text = "5";
            this.fiveButton.UseVisualStyleBackColor = true;
            this.fiveButton.Click += new System.EventHandler(this.fiveButton_Click);
            // 
            // sixButton
            // 
            this.sixButton.Location = new System.Drawing.Point(168, 132);
            this.sixButton.Name = "sixButton";
            this.sixButton.Size = new System.Drawing.Size(75, 23);
            this.sixButton.TabIndex = 8;
            this.sixButton.Text = "6";
            this.sixButton.UseVisualStyleBackColor = true;
            this.sixButton.Click += new System.EventHandler(this.sixButton_Click);
            // 
            // multButton
            // 
            this.multButton.Location = new System.Drawing.Point(249, 132);
            this.multButton.Name = "multButton";
            this.multButton.Size = new System.Drawing.Size(75, 23);
            this.multButton.TabIndex = 9;
            this.multButton.Text = "*";
            this.multButton.UseVisualStyleBackColor = true;
            this.multButton.Click += new System.EventHandler(this.multButton_Click);
            // 
            // oneButton
            // 
            this.oneButton.Location = new System.Drawing.Point(6, 161);
            this.oneButton.Name = "oneButton";
            this.oneButton.Size = new System.Drawing.Size(75, 23);
            this.oneButton.TabIndex = 10;
            this.oneButton.Text = "1";
            this.oneButton.UseVisualStyleBackColor = true;
            this.oneButton.Click += new System.EventHandler(this.oneButton_Click);
            // 
            // twoButton
            // 
            this.twoButton.Location = new System.Drawing.Point(87, 161);
            this.twoButton.Name = "twoButton";
            this.twoButton.Size = new System.Drawing.Size(75, 23);
            this.twoButton.TabIndex = 11;
            this.twoButton.Text = "2";
            this.twoButton.UseVisualStyleBackColor = true;
            this.twoButton.Click += new System.EventHandler(this.twoButton_Click);
            // 
            // threeButton
            // 
            this.threeButton.Location = new System.Drawing.Point(168, 161);
            this.threeButton.Name = "threeButton";
            this.threeButton.Size = new System.Drawing.Size(75, 23);
            this.threeButton.TabIndex = 12;
            this.threeButton.Text = "3";
            this.threeButton.UseVisualStyleBackColor = true;
            this.threeButton.Click += new System.EventHandler(this.threeButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(327, 132);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 13;
            this.clearButton.Text = "C";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // zeroButton
            // 
            this.zeroButton.Location = new System.Drawing.Point(6, 190);
            this.zeroButton.Name = "zeroButton";
            this.zeroButton.Size = new System.Drawing.Size(156, 23);
            this.zeroButton.TabIndex = 15;
            this.zeroButton.Text = "0";
            this.zeroButton.UseVisualStyleBackColor = true;
            this.zeroButton.Click += new System.EventHandler(this.zeroButton_Click);
            // 
            // decimalButton
            // 
            this.decimalButton.Location = new System.Drawing.Point(168, 190);
            this.decimalButton.Name = "decimalButton";
            this.decimalButton.Size = new System.Drawing.Size(75, 23);
            this.decimalButton.TabIndex = 16;
            this.decimalButton.Text = ".";
            this.decimalButton.UseVisualStyleBackColor = true;
            this.decimalButton.Click += new System.EventHandler(this.decimalButton_Click);
            // 
            // minusButton
            // 
            this.minusButton.Location = new System.Drawing.Point(249, 161);
            this.minusButton.Name = "minusButton";
            this.minusButton.Size = new System.Drawing.Size(75, 23);
            this.minusButton.TabIndex = 17;
            this.minusButton.Text = "-";
            this.minusButton.UseVisualStyleBackColor = true;
            this.minusButton.Click += new System.EventHandler(this.minusButton_Click);
            // 
            // equalsButton
            // 
            this.equalsButton.Location = new System.Drawing.Point(330, 161);
            this.equalsButton.Name = "equalsButton";
            this.equalsButton.Size = new System.Drawing.Size(72, 52);
            this.equalsButton.TabIndex = 18;
            this.equalsButton.Text = "=";
            this.equalsButton.UseVisualStyleBackColor = true;
            this.equalsButton.Click += new System.EventHandler(this.equalsButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(249, 190);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 23);
            this.addButton.TabIndex = 19;
            this.addButton.Text = "+";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // calGroup
            // 
            this.calGroup.Controls.Add(this.zeroButton);
            this.calGroup.Controls.Add(this.minusButton);
            this.calGroup.Controls.Add(this.numbLabel);
            this.calGroup.Controls.Add(this.bkspcButton);
            this.calGroup.Controls.Add(this.clearButton);
            this.calGroup.Controls.Add(this.divideButton);
            this.calGroup.Controls.Add(this.equalsButton);
            this.calGroup.Controls.Add(this.nineButton);
            this.calGroup.Controls.Add(this.multButton);
            this.calGroup.Controls.Add(this.eightButton);
            this.calGroup.Controls.Add(this.addButton);
            this.calGroup.Controls.Add(this.sevenButton);
            this.calGroup.Controls.Add(this.sixButton);
            this.calGroup.Controls.Add(this.decimalButton);
            this.calGroup.Controls.Add(this.fiveButton);
            this.calGroup.Controls.Add(this.threeButton);
            this.calGroup.Controls.Add(this.fourButton);
            this.calGroup.Controls.Add(this.oneButton);
            this.calGroup.Controls.Add(this.twoButton);
            this.calGroup.Location = new System.Drawing.Point(70, 76);
            this.calGroup.Name = "calGroup";
            this.calGroup.Size = new System.Drawing.Size(528, 213);
            this.calGroup.TabIndex = 20;
            this.calGroup.TabStop = false;
            this.calGroup.Enter += new System.EventHandler(this.calGroup_Enter);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calGroup);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.calGroup.ResumeLayout(false);
            this.calGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label numbLabel;
        private System.Windows.Forms.Button sevenButton;
        private System.Windows.Forms.Button eightButton;
        private System.Windows.Forms.Button nineButton;
        private System.Windows.Forms.Button divideButton;
        private System.Windows.Forms.Button bkspcButton;
        private System.Windows.Forms.Button fourButton;
        private System.Windows.Forms.Button fiveButton;
        private System.Windows.Forms.Button sixButton;
        private System.Windows.Forms.Button multButton;
        private System.Windows.Forms.Button oneButton;
        private System.Windows.Forms.Button twoButton;
        private System.Windows.Forms.Button threeButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button zeroButton;
        private System.Windows.Forms.Button decimalButton;
        private System.Windows.Forms.Button minusButton;
        private System.Windows.Forms.Button equalsButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.GroupBox calGroup;
    }
}

